﻿onmessage = function (msgFromMainThread) {
    console.log('Message from Main Thread : ' + msgFromMainThread.data);
    //console.log(XMLHttpRequest);
    var myArrayData = [];
    for (var i = 0; i < 2000; i++) {
        myArrayData[i] = [];
        for (var j = 0; j < 3000; j++) {
            myArrayData[i][j] = Math.random();
        }
    }
    postMessage(myArrayData);
}