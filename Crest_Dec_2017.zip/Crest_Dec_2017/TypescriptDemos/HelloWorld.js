var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 10; // type inference
var y; // type annotations
var boolVar;
var stringVar;
var anytype;
anytype = 10;
anytype = true;
anytype = { name: 'Crest' };
function Add(x, y) {
    if (x > 100) {
        return 'x is greater than 100 !';
    }
    return x + y;
}
var result = Add(20, 30);
// Arrays
var cars = ['BMW', 'Audi', 'Ferrari'];
var moreCars = new Array('Mahindra', 'Tata', 'Maruti'); // Generics
var companies = [
    { Name: 'Accenture', Location: 'Hyderabad' },
    { Name: 'Crest', Location: 'Pune' }
];
// for(var c in cars){
//     console.log(cars[c]);
// }
for (var _i = 0, cars_1 = cars; _i < cars_1.length; _i++) {
    var c = cars_1[_i];
    console.log(c);
}
function GetAllBooks() {
    var books = [
        { title: 'Wings Of Fire', price: 300, author: 'Dr. APJ Abdul Kalam' },
        { title: 'I am Malala', price: 700, author: 'Malala' },
        { title: 'Playing It My Way', price: 300, author: 'Sachin Tendulkar' },
        { title: 'Mrutunjay', price: 600, author: 'Ranjit Desai' },
        { title: 'Chava', price: 300, author: 'Ranjit Desai' }
    ];
    return books;
}
var allBooks = GetAllBooks();
for (var _a = 0, allBooks_1 = allBooks; _a < allBooks_1.length; _a++) {
    var book = allBooks_1[_a];
    console.log(book.title + " costs Rs." + book.price);
}
// if(true){
//     let s = "Typescript !";
//     if(true){
//         let s = "Angular !";
//         console.log(s);        
//     }    
// }
var PI = 3.14;
// Optional Parameters
// function PrintBooks(noOfPages:number,publication?:string){
// }
// Default Parameters
// function PrintBooks(noOfPages:number,publication:string="Mehta"){
//     console.log(noOfPages,publication);
// }
//PrintBooks(600);
//PrintBooks(1000,"Vision");
// Rest parameters
function PrintBooks(author) {
    var books = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        books[_i - 1] = arguments[_i];
    }
    console.log(author, books);
}
PrintBooks("Ranjit Desai", "Chava", "Mrutyunjay", "Laalbaug");
PrintBooks("Dr. APJ Kalam", "India 2010", "Wings of Fire");
PrintBooks("Don Shori");
// function Square(x:number):number{
//     return x * x;
// }
// Function as an expression !
// let Square = function(x:number):number{
//         return x * x;
//      }
var Square = function (x) { return x * x; };
var Addition = function (x, y) { return x + y; };
function Emp() {
    var _this = this;
    this.EmpId = 1;
    this.Salary = 10000;
    setTimeout(function () {
        console.log(_this.Salary); // print ??
    }, 2000);
}
var eObj = new Emp();
// OOP
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = ""; }
        if (speed === void 0) { speed = 0; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.Accelerate = function (currSpeed) {
        return (this.name + " is running at " + currSpeed + " kmph !");
    };
    return Car;
}());
// var carObj = new Car("i30",300)
// carObj.Accelerate(300);
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, canfly, cansub) {
        var _this = _super.call(this, name, speed) || this;
        _this.canFly = canfly;
        _this.canSubmerge = cansub;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function (currSpeed) {
        return _super.prototype.Accelerate.call(this, currSpeed) + " Canfly ? : " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 400, true, true);
console.log(jbc.Accelerate(450));
//let aPerson:IPerson = {name:'Sumeet',age:34};
var Person = /** @class */ (function () {
    function Person() {
    }
    Person.prototype.getDetails = function () {
        console.log(this.name + " is of " + this.age + " years !");
    };
    return Person;
}());
