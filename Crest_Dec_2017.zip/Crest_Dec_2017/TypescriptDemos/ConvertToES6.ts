let testVar:number = 10;

function Product(x:any,y:any){
    return x + y;
}