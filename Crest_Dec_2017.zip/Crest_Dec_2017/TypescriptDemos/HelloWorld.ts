var x = 10;// type inference
var y:number; // type annotations
var boolVar:boolean;
var stringVar:string;
var anytype:any;
anytype = 10;
anytype = true;
anytype = {name:'Crest'};

function Add(x:number,y:number):number | string{
    if(x>100){
        return 'x is greater than 100 !';
    }
    return x + y;
}

var result = Add(20,30);

// Arrays

var cars:string[] = ['BMW','Audi','Ferrari'];
var moreCars:Array<string> = new Array<string>('Mahindra','Tata','Maruti'); // Generics

var companies:any[] = [
    {Name:'Accenture',Location:'Hyderabad'},
    {Name:'Crest',Location:'Pune'}    
];


// for(var c in cars){
//     console.log(cars[c]);
// }

for(var c of cars){
    console.log(c);    
}


interface IBook{
    title:string;
    author:string;
    price:number;
}

function GetAllBooks():IBook[]{
    var books:IBook[]=[
        {title:'Wings Of Fire',price:300,author:'Dr. APJ Abdul Kalam'},
        {title:'I am Malala',price:700,author:'Malala'},
        {title:'Playing It My Way',price:300,author:'Sachin Tendulkar'},
        {title:'Mrutunjay',price:600,author:'Ranjit Desai'},
        {title:'Chava',price:300,author:'Ranjit Desai'}
        ];
     return books;
}

var allBooks:IBook[] = GetAllBooks();

for(var book of allBooks){
    console.log(book.title + " costs Rs." + book.price);
}


// if(true){
//     let s = "Typescript !";
//     if(true){
//         let s = "Angular !";
//         console.log(s);        
//     }    
// }

const PI:number = 3.14;


// Optional Parameters

// function PrintBooks(noOfPages:number,publication?:string){

// }

// Default Parameters

// function PrintBooks(noOfPages:number,publication:string="Mehta"){
//     console.log(noOfPages,publication);
// }

//PrintBooks(600);

//PrintBooks(1000,"Vision");

// Rest parameters

function PrintBooks(author:string,...books:string[]){
    console.log(author,books);
}


PrintBooks("Ranjit Desai","Chava","Mrutyunjay","Laalbaug");
PrintBooks("Dr. APJ Kalam","India 2010","Wings of Fire");
PrintBooks("Don Shori");


// function Square(x:number):number{
//     return x * x;
// }

// Function as an expression !
// let Square = function(x:number):number{
//         return x * x;
//      }

let Square = (x:number):number =>  x * x;

let Addition = (x:number,y:number):number => x+y;


function Emp(){
    this.EmpId = 1;
    this.Salary = 10000;
    setTimeout(()=>{                
            console.log(this.Salary); // print ??
    },2000)
}

var eObj = new Emp();

// OOP

class Car{
    name:string;
    speed:number;   
    
    constructor(name:string="",speed:number=0){
        this.name = name;
        this.speed = speed;
    }

    Accelerate(currSpeed:number):string{
       return (this.name + " is running at " + currSpeed + " kmph !" );
    }
}

// var carObj = new Car("i30",300)
// carObj.Accelerate(300);

class JamesBondCar extends Car{
    canFly:boolean;
    canSubmerge:boolean;

    constructor(name:string,speed:number,canfly:boolean,cansub:boolean){
        super(name,speed);
        this.canFly = canfly;
        this.canSubmerge = cansub;
    }

    Accelerate(currSpeed:number):string{
          return  super.Accelerate(currSpeed) + " Canfly ? : " + this.canFly
    }
}

var jbc = new JamesBondCar("Houston",400,true,true);
console.log(jbc.Accelerate(450));

interface IPerson{
    name:string;
    age:number;
    getDetails:() => void;
}


//let aPerson:IPerson = {name:'Sumeet',age:34};

class Person implements IPerson{
    name:string;
    age:number;
    getDetails(){
        console.log(this.name + " is of " + this.age + " years !")
    }
}
