import {Component} from '@angular/core';
import {PostsService} from './posts.service';

@Component({
    selector:`post`,
    template:`<h1> Posts</h1>
    
    {{ postsData | json   }}
    
    `,
    providers:[PostsService]
})
export class PostsComponent{

    postsData:any[] = [];

        constructor(private servObj:PostsService){
             let aPromise =   this.servObj.getPosts(); // returns a promise !
             aPromise.then((dataFromService)=>{
                 this.postsData =  dataFromService.json();
             },(err)=>{

             })
        }
}