import {Pipe,PipeTransform} from '@angular/core'

@Pipe({name:'stockduration'})
export class StockPipe implements PipeTransform {
        transform(valuePassed:number,args:string){
                return valuePassed + " " + args;
        }
}