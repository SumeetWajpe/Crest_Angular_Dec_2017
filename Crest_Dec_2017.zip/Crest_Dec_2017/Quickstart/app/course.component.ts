
import {Component,Input} from '@angular/core';

@Component({
    selector:'course',
    template:`<h1> Learning {{ coursedetails.name }}   </h1>
    <b> Duration : {{coursedetails.duration }} </b> <br/>
    <!-- <img src="{{imageUrl}}" />
     <img [src]="imageUrl" /> -->

    
    `
  
})
export class CourseComponent{
    @Input()     coursedetails:any = {};
    // coursename:string = "Angular 2.0";
    imageUrl:string='https://d2eip9sf3oo6c2.cloudfront.net/series/square_covers/000/000/033/thumb/egghead-angular-material-course-sq.png'

}

