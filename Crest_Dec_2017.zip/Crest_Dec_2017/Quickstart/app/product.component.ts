
import {Component,Input} from '@angular/core';

@Component({
    selector:'product',
    template:`

   <!-- <div [ngClass]="['BorderedStyle','ProductStyle']"> -->

   <!--<div [ngClass]="{'BorderedStyle':true,'ProductStyle':false}">-->
   
   <div [ngClass]="['BorderedStyle','ProductStyle']">
   <h1> {{prodDetails.title | uppercase | lowercase   }} </h1>
    <img [src]="prodDetails.ImageUrl" height="100px" width="100px" /> 
    <br/>
           
    Is Free ? : <input type="checkbox" [(ngModel)] = "isFree" />
    <div *ngIf="!isFree">
    <b [style.backgroundColor]="(prodDetails.price > 10000) ? 'red' : 'green' "> Price :  </b> {{prodDetails.price | currency:'INR':true  }}
    </div>
    <br/>
    
    <b> Quantity :  </b> {{prodDetails.quantity}} <br/>
    
    <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2'  }} <br/>


    <b> Stock Lasts : </b> {{ prodDetails.stockLasts |  stockduration:'months' }}  <br/>

    <b>Raw Data : </b> {{ prodDetails | json }} <br/>
</div>
    `  ,
    // styles:[
    //     `
    //     .ProductStyle{
    //         background-color: lightblue; 
    //         padding:10px;
    //         margin:10px;
    //       }
          
    //       .BorderedStyle{
    //         border:2px solid red;
    //         border-radius: 10px;
    //       }
    //     `    ]
    styleUrls:['./app/productstyles.css']
})
export class ProductComponent{
    @Input()     prodDetails:any = {};
    isFree:boolean = true;
    classToBeApplied:string = "ProductStyle";
  
}

