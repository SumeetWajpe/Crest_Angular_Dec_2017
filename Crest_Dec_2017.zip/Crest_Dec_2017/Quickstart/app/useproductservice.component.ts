import {Component} from '@angular/core';
import {ProductService} from './product.service';

@Component({
    selector:`useproductserv`,
    template:``,
    providers:[ProductService]
})
export class UseProductService{
        constructor(public servObj:ProductService){
               console.log(this.servObj.getRandomProduct());
        }
}