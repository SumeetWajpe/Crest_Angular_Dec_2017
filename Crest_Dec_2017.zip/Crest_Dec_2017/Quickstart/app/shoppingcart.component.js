"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ShoppingCartComponent = (function () {
    function ShoppingCartComponent() {
        this.heading = "Amazon";
        this.inputData = "";
        this.products = [
            { title: 'Mobile', price: 20000, stockLasts: 2, quantity: 1000, rating: 5, ImageUrl: 'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg' },
            { title: 'Laptop', price: 50000, stockLasts: 5, quantity: 100, rating: 4, ImageUrl: 'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70' },
            { title: 'Desktop', price: 10000, stockLasts: 10, quantity: 200, rating: 3, ImageUrl: 'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg' },
            { title: 'LED TV', price: 25000, stockLasts: 3, quantity: 10, rating: 3.5674, ImageUrl: 'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg' },
            { title: 'Camera', price: 90000, stockLasts: 7, quantity: 10, rating: 4, ImageUrl: 'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png' }
        ];
    }
    ShoppingCartComponent.prototype.ChangeHeading = function () {
        this.heading = "Amazon";
    };
    ShoppingCartComponent.prototype.HandleTwoWayBinding = function (e) {
        // console.log(e.target); // the element on which the event occurred !
        this.heading = e.target.value;
    };
    ShoppingCartComponent.prototype.ChangeHandlerOnClick = function () {
        this.heading = this.inputData;
    };
    return ShoppingCartComponent;
}());
ShoppingCartComponent = __decorate([
    core_1.Component({
        selector: 'cart',
        template: "\n\n  <h1>{{ heading | uppercase }} </h1>\n\n  <input type=\"text\" [value]=\"heading\"\n   (input)=\"HandleTwoWayBinding($event)\" />\n\n   <input type=\"text\" [(ngModel)]=\"inputData\" />\n\n   <input type=\"button\" value=\"Change !\" (click)=\"ChangeHandlerOnClick()\" />\n\n  <!--<input type=\"button\" value=\"Change Heading !\" (click)=\"ChangeHeading()\" />-->\n\n  <div *ngFor=\"let p of products\">\n  <product  [prodDetails]=\"p\" ></product>\n  </div>   \n  "
    })
], ShoppingCartComponent);
exports.ShoppingCartComponent = ShoppingCartComponent;
//# sourceMappingURL=shoppingcart.component.js.map