import  {Http} from '@angular/http'; // Http is a service !
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostsService{
        constructor(private httpObj:Http){

        }

        // getPosts(){
        //     // make ajaxified request !
        //     this.httpObj.get('https://jsonplaceholder.typicode.com/posts').subscribe(function(dataFromServer){
        //             return dataFromServer.json();
        //     });
        // }

        getPosts(){
            // make ajaxified request !
         return   this.httpObj.
         get('https://jsonplaceholder.typicode.com/posts').toPromise();
                
        }
}